import sqlite3
import os
from slackclient import SlackClient

slack_client = SlackClient(os.environ.get('SLACK_BOT_TOKEN'))

def get_week(slack_id):
    connection = sqlite3.connect('byte_master.db', check_same_thread = False)
    cursor     = connection.cursor()
    sql_statment = "SELECT week, end_students FROM cohorts WHERE slack_channel= '{}';".format(slack_id)
    cursor.execute(sql_statment)
    response = cursor.fetchone()
    week = response[0]
    students = response[1]
    print(week)
    return week, students

def obtain_topics(week, students):
    connection = sqlite3.connect('byte_master.db', check_same_thread = False)
    cursor     = connection.cursor()
    prezzys = []
    for _ in range(1, students+1):
        cursor.execute("SELECT topic_{} FROM presentations WHERE pk= '{}';".format(_, week))
        prez = cursor.fetchone()
        prezzys.append(prez[0])
    print(prezzys)
    return prezzys

def dispatch_topics(topic_list, slack_id):
    topics = '\n'.join(topic_list)
    response = 'Please see quiz topics below:\n' + topics
    slack_client.api_call(
        "chat.postMessage",
        channel = slack_id,
        #channel='{}'.format(slack_id),
        text= response,
        username='PresentationBot',
        icon_emoji=':byte:'
    )

def presentation_protocol(cohorts):
    for cohort in cohorts:
        week, students = get_week(cohort[1])
        topics = obtain_topics(week, students)
        dispatch_topics(topics, cohort)
